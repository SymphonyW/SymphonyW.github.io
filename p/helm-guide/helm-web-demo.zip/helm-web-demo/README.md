# Helm Nginx learning example

解压后进入本目录。需要 Helm 3 或 4、kubectl，以及可访问的练习 Kubernetes 集群。

本示例使用教学镜像标签，不代表生产部署建议。

## 本地检查（不访问集群）

```sh
helm lint ./web-demo
helm template demo ./web-demo -n helm-lab
helm template demo ./web-demo -n helm-lab -f values-prod.yaml
```

## 安装与访问（会修改当前 context 指向的集群）

```sh
kubectl config current-context
kubectl get nodes
helm install demo ./web-demo -n helm-lab --create-namespace --wait --timeout 3m
kubectl port-forward svc/demo-web 8080:80 -n helm-lab
```

打开 http://localhost:8080 。保持端口转发运行；Ctrl+C 只停止转发。

## 升级、回滚、清理

```sh
helm upgrade demo ./web-demo -n helm-lab --set replicaCount=2 --wait --timeout 3m
helm history demo -n helm-lab
# 先确认 revision 1 是想恢复的版本
helm rollback demo 1 -n helm-lab --wait --timeout 3m
helm uninstall demo -n helm-lab
```

Helm 3 升级失败回滚参数为 --atomic；Helm 4 使用 --rollback-on-failure。
回滚不恢复数据库等外部状态。卸载不会自动删除 namespace。

多环境文件只演示差异；values-prod.yaml 不表示已经具备完整生产配置。

## Verification scope

Chart linting and local rendering are checked with Helm 3.19.0 and 4.0.0.
Live cluster install, image pulling, browser access, upgrade, and rollback require your lab cluster.
