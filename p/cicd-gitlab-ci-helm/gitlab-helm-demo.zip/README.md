# GitLab CI + Helm demo / 示例

This is a teaching project, not a ready-made production platform.
这是教学项目；需要自行提供 GitLab Runner、镜像仓库与 Kubernetes 集群。

## Local / 本地

Node.js 22+: `node --test server.test.mjs`, then `node server.mjs`.
The app exposes `/`, `/healthz`, `/readyz` on port 3000.
It deliberately has no npm dependencies or separate compile step.

## GitLab prerequisites / 前置配置

1. Copy ALL files, including `.gitlab-ci.yml` and `.dockerignore`, to a NEW
   GitLab project's repository root. Do not replace this blog's CI config.
2. Enable GitLab Container Registry. Protect the default branch and review merges.
3. Register Linux container runners tagged `container`; register an isolated,
   protected Docker executor tagged `docker-build` with privileged DinD enabled
   and `/certs/client` shared with the job container (see GitLab's TLS DinD docs).
   Register a protected runner tagged `deploy` with access to the cluster API.
4. Set `DEPLOY_TOOLS_IMAGE` to a reviewed Linux image containing Helm 3 and
   `/bin/sh`, `chmod`, `mkdir`. Its registry must be reachable by all relevant
   runners, including the MR validation runner. Pin it by digest in production.
5. Precreate namespaces `demo-staging` and `demo-production`. In EACH namespace,
   create a `registry-pull` imagePullSecret with a dedicated read_registry
   deploy token. Do NOT use an expiring CI_JOB_TOKEN as the cluster pull secret.
6. Create two protected FILE-type GitLab variables named `KUBE_CONFIG`, scoped
   respectively to environments `staging` and `production`. Each kubeconfig
   must have its current context set and use a separate identity restricted to
   the relevant namespace. Helm needs access to release Secrets as well as
   Deployments, Services, and test Pods/logs. Configure both variables before
   running a default-branch pipeline. Do not use this env-scoped secret in rules.
7. Enable prevention of outdated deployment jobs. Restrict production deployers
   with protected environments where your GitLab tier supports it. The manual
   job in YAML is a blocking trigger; it is not an independent approval policy.

Runner TLS configuration, RBAC, credentials and cluster provisioning are
environment-specific and intentionally not created by this project.

Merge requests run app checks and chart lint/render/package only. A default-branch
push also builds and pushes one image, deploys to staging and runs a smoke test.
Production is a blocking manual job and reuses the SAME digest and chart package.
The single-platform image assumes build runners and target nodes share a CPU
architecture; use a tested multi-platform build when they differ.

CI uses Helm 3 `--atomic`; Helm 4 uses `--rollback-on-failure` instead. Pin a major
version and validate behavior before migrating. Major image tags in this demo
are for readability, not a claim of supply-chain reproducibility or currency.

Artifacts expire after 30 days. Archive the image digest, chart package, commit,
environment values and verification result in durable release storage for
longer-lived production approvals and disaster recovery.

## Failure / 失败处理

`--atomic` applies to the upgrade operation, not to the subsequent `helm test`.
Test Pods are retained for `--logs` and inspection, then replaced before the
next test run. Do not delete successful Pods before Helm retrieves their logs.
If smoke fails after a successful upgrade, deployment fails but the installed
release remains. Inspect it and explicitly roll back to a known good revision:

```sh
helm history demo -n demo-production
helm rollback demo <KNOWN_GOOD_REVISION> -n demo-production --wait --timeout 5m
helm test demo -n demo-production --logs --timeout 2m
```

Do not blindly retry an old pipeline. Check the intended commit and digest first.
Helm rollback does not reverse database migrations, external side effects or CRDs.
